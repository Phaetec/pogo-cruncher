
import os
import sys

# add directory of this file to PATH, so that the package will be found
sys.path.append(os.path.dirname(os.path.realpath(__file__)))

__title__ = 'pgoapi_protos_POGOProtos'
__version__ = '1.1.5'

__commit__ = 'cbf0b0843dd944bd895b97d0f3bf7820e8c84339'
__commit_tree__ = 'https://github.com/AeonLucid/POGOProtos/tree/cbf0b0843dd944bd895b97d0f3bf7820e8c84339'
__author__ = 'AeonLucid'
__copyright__ = 'Copyright (c) 2016 AeonLucid <https://github.com/AeonLucid>'