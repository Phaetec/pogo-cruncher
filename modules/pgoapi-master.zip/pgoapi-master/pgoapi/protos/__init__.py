
import os
import sys

# add directory of this file to PATH, so that the package will be found
sys.path.append(os.path.dirname(os.path.realpath(__file__)))

__title__ = 'pgoapi_protos_POGOProtos'
__version__ = '1.1.6'

__commit__ = '333e54707ca221324c6b9eedb6a7bc2fcae02270'
__commit_tree__ = 'https://github.com/AeonLucid/POGOProtos/tree/333e54707ca221324c6b9eedb6a7bc2fcae02270'
__author__ = 'AeonLucid'
__copyright__ = 'Copyright (c) 2016 AeonLucid <https://github.com/AeonLucid>'